'use strict';

document.documentElement.classList.add('js');

const root = document.documentElement;
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = themeToggle?.querySelector('.theme-icon');
const themeMeta = document.querySelector('meta[name="theme-color"]');
const toast = document.getElementById('toast');
const linkStatus = document.getElementById('link-status');
let toastTimeout;

function safeGetTheme() {
  try {
    return localStorage.getItem('theme');
  } catch (error) {
    return null;
  }
}

function safeSaveTheme(theme) {
  try {
    localStorage.setItem('theme', theme);
  } catch (error) {
    // O tema continua funcionando mesmo se o navegador bloquear o armazenamento.
  }
}

function applyTheme(theme, save = true) {
  const normalizedTheme = theme === 'light' ? 'light' : 'dark';
  root.setAttribute('data-theme', normalizedTheme);

  const isDark = normalizedTheme === 'dark';
  if (themeToggle) {
    themeToggle.setAttribute('aria-pressed', String(isDark));
    themeToggle.setAttribute(
      'aria-label',
      isDark ? 'Tema escuro ativado. Ativar tema claro' : 'Tema claro ativado. Ativar tema escuro'
    );
  }
  if (themeIcon) themeIcon.textContent = isDark ? '☼' : '☾';
  if (themeMeta) themeMeta.setAttribute('content', isDark ? '#3F0D05' : '#FFEADD');
  if (save) safeSaveTheme(normalizedTheme);
}

function initTheme() {
  const savedTheme = safeGetTheme();
  if (savedTheme === 'light' || savedTheme === 'dark') {
    applyTheme(savedTheme, false);
    return;
  }

  // A versão escura é o visual principal; novos visitantes começam nela.
  applyTheme('dark', false);
}

themeToggle?.addEventListener('click', () => {
  const currentTheme = root.getAttribute('data-theme');
  applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
});

function showToast(message) {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('is-visible');
  window.clearTimeout(toastTimeout);
  toastTimeout = window.setTimeout(() => {
    toast.classList.remove('is-visible');
  }, 3200);
}

document.querySelectorAll('[data-placeholder-link="true"]').forEach((link) => {
  link.addEventListener('click', (event) => {
    event.preventDefault();
    const name = link.dataset.linkName || 'Este link';
    const message = `${name}: endereço provisório. Substitua o href no index.html quando tiver o link definitivo.`;
    if (linkStatus) linkStatus.textContent = message;
    showToast(message);
  });
});

function initRevealAnimations() {
  const revealItems = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) {
    revealItems.forEach((item) => item.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        currentObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.14, rootMargin: '0px 0px -35px 0px' });

  revealItems.forEach((item) => observer.observe(item));
}

function initPosterParallax() {
  const poster = document.getElementById('poster-art');
  const pointerFine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!poster || !pointerFine || reducedMotion) return;

  poster.addEventListener('pointermove', (event) => {
    const rect = poster.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    poster.style.setProperty('--pointer-x', `${x * 7}px`);
    poster.style.setProperty('--pointer-y', `${y * 7}px`);
  });

  poster.addEventListener('pointerleave', () => {
    poster.style.setProperty('--pointer-x', '0px');
    poster.style.setProperty('--pointer-y', '0px');
  });
}

function initFooterYear() {
  const year = document.getElementById('current-year');
  if (year) year.textContent = String(new Date().getFullYear());
}

initTheme();
initRevealAnimations();
initPosterParallax();
initFooterYear();